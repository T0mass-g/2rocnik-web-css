import json


# ============================================================
# UKLADANIE A NAČÍTANIE DÁT
# ------------------------------------------------------------
# Tento modul nepozná menu ani spôsob zobrazenia úloh.
# Iba uloží alebo načíta zoznam úloh zo súboru.
# ============================================================


def uloz_ulohy(zoznam, nazov_suboru):
    with open(nazov_suboru, "w", encoding="utf-8") as subor:
        json.dump(zoznam, subor, ensure_ascii=False)


def nacitaj_ulohy(nazov_suboru):
    try:
        with open(nazov_suboru, "r", encoding="utf-8") as subor:
            return json.load(subor)
    except:
        return []
