# ============================================================
# LOGIKA TO-DO APLIKÁCIE
# ------------------------------------------------------------
# Funkcie v tomto súbore pracujú s dátami úloh.
# Nepoužívajú input() ani print().
#
# Dnešný cieľ:
# pri filtrovaní nestratiť informáciu o pôvodnom indexe úlohy.
# ============================================================


def filtruj_ulohy(zoznam, filter_r):
    """Vráti iba úlohy, ktoré patria do zvoleného filtra."""
    vysledok = []

    for uloha in zoznam:
        if filter_r == "vsetky":
            vysledok.append(uloha)
        elif filter_r == "hotove" and uloha["hotovo"]:
            vysledok.append(uloha)
        elif filter_r == "nesplnene" and not uloha["hotovo"]:
            vysledok.append(uloha)

    return vysledok


def pridaj_ulohu(zoznam, text):
    """Pridá novú nesplnenú úlohu do zoznamu."""
    nova = {"text": text, "hotovo": False}
    zoznam.append(nova)


def oznac_hotove(zoznam, cislo):
    """Označí úlohu podľa poradového čísla ako hotovú.

    Táto pôvodná funkcia používa číslovanie od 1.
    Nechávame ju tu kvôli porovnaniu.
    """
    if 1 <= cislo <= len(zoznam):
        zoznam[cislo - 1]["hotovo"] = True
        return True
    else:
        return False


# ============================================================
# NOVÉ FUNKCIE PRE PRÁCU S FILTROM A INDEXMI
# ============================================================


def filtruj_ulohy_s_indexom(zoznam, filter_r):
    """Vráti dvojice (pôvodný_index, úloha), ktoré patria do filtra.

    Príklad výsledku:
    [
        (0, {"text": "Napísať domácu úlohu", "hotovo": False}),
        (2, {"text": "Pripraviť sa na test", "hotovo": False})
    ]

    TODO:
    - prejdi zoznam pomocou enumerate(zoznam),
    - ak úloha patrí do filtra, pridaj do výsledku dvojicu (index, uloha),
    - vráť výsledok.
    """
    vysledok = []

    # TODO: doplň riešenie

    return vysledok


def povodny_index_podla_poradia(zoznam, filter_r, poradie):
    """Preloží zobrazené poradie vo filtrovanom zozname na pôvodný index.

    Používateľ zadáva poradie od 1.
    Program v zozname pracuje s indexom od 0.

    Ak poradie neexistuje, vráť -1.

    Príklad:
    Pri filtri "nesplnene" používateľ zadá 2.
    Funkcia má vrátiť pôvodný index úlohy, ktorá je vo filtrovanom výpise druhá.
    """
    vybrane = filtruj_ulohy_s_indexom(zoznam, filter_r)

    # TODO:
    # 1. Ak je poradie menšie ako 1 alebo väčšie ako počet vybraných úloh, vráť -1.
    # 2. Inak z vybrane[poradie - 1] zober pôvodný index.
    # 3. Vráť pôvodný index.

    return -1


def oznac_hotove_indexom(zoznam, index):
    """Označí úlohu podľa pôvodného indexu od 0 ako hotovú.

    Ak je index neplatný, vráti False.
    Ak sa označenie podarí, vráti True.
    """
    # TODO:
    # 1. Skontroluj, či index je platný: 0 <= index < len(zoznam).
    # 2. Ak je platný, nastav zoznam[index]["hotovo"] = True a vráť True.
    # 3. Inak vráť False.

    return False
