"""
Kontrola logiky indexov.

Spusti tento súbor po doplnení ulohy_logika_TODO.py.

Ak je riešenie správne, zobrazí sa:
Kontrola logiky indexov prešla.
"""

from ulohy_logika_TODO import (
    filtruj_ulohy_s_indexom,
    povodny_index_podla_poradia,
    oznac_hotove_indexom,
)


def testovaci_zoznam():
    return [
        {"text": "Napísať domácu úlohu", "hotovo": False},
        {"text": "Prečítať kapitolu", "hotovo": True},
        {"text": "Pripraviť sa na test", "hotovo": False},
        {"text": "Odovzdať projekt", "hotovo": False},
    ]


def spusti_kontrolu():
    ulohy = testovaci_zoznam()

    nesplnene = filtruj_ulohy_s_indexom(ulohy, "nesplnene")
    assert len(nesplnene) == 3, "Filter 'nesplnene' má vrátiť tri úlohy."
    assert nesplnene[0][0] == 0, "Prvá zobrazená nesplnená úloha má pôvodný index 0."
    assert nesplnene[1][0] == 2, "Druhá zobrazená nesplnená úloha má pôvodný index 2."
    assert nesplnene[2][0] == 3, "Tretia zobrazená nesplnená úloha má pôvodný index 3."

    hotove = filtruj_ulohy_s_indexom(ulohy, "hotove")
    assert len(hotove) == 1, "Filter 'hotove' má vrátiť jednu úlohu."
    assert hotove[0][0] == 1, "Hotová úloha má pôvodný index 1."

    vsetky = filtruj_ulohy_s_indexom(ulohy, "vsetky")
    assert len(vsetky) == 4, "Filter 'vsetky' má vrátiť štyri úlohy."
    assert [dvojica[0] for dvojica in vsetky] == [0, 1, 2, 3], "Pri filtri 'vsetky' majú indexy zostať 0, 1, 2, 3."

    assert povodny_index_podla_poradia(ulohy, "nesplnene", 1) == 0, "Nesplnené poradie 1 má pôvodný index 0."
    assert povodny_index_podla_poradia(ulohy, "nesplnene", 2) == 2, "Nesplnené poradie 2 má pôvodný index 2."
    assert povodny_index_podla_poradia(ulohy, "nesplnene", 3) == 3, "Nesplnené poradie 3 má pôvodný index 3."
    assert povodny_index_podla_poradia(ulohy, "nesplnene", 4) == -1, "Neexistujúce poradie má vrátiť -1."
    assert povodny_index_podla_poradia(ulohy, "nesplnene", 0) == -1, "Poradie 0 je neplatné."

    vysledok = oznac_hotove_indexom(ulohy, 2)
    assert vysledok is True, "Platný index 2 sa má dať označiť."
    assert ulohy[2]["hotovo"] is True, "Úloha s pôvodným indexom 2 má byť hotová."

    vysledok = oznac_hotove_indexom(ulohy, -1)
    assert vysledok is False, "Záporný index je neplatný."

    vysledok = oznac_hotove_indexom(ulohy, 99)
    assert vysledok is False, "Príliš veľký index je neplatný."


if __name__ == "__main__":
    spusti_kontrolu()
    print("Kontrola logiky indexov prešla.")
