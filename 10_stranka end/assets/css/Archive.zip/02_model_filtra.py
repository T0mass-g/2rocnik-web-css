"""
KROK 2 — Model filtra.

Spusti tento súbor.
Nič v ňom nemusíš upravovať.

Úloha:
Sleduj rozdiel medzi pôvodným indexom a zobrazeným poradím.
"""

ulohy = [
    {"text": "Napísať domácu úlohu", "hotovo": False},
    {"text": "Prečítať kapitolu", "hotovo": True},
    {"text": "Pripraviť sa na test", "hotovo": False},
]


print("PÔVODNÝ ZOZNAM:")
for index, uloha in enumerate(ulohy):
    stav = "[x]" if uloha["hotovo"] else "[ ]"
    print(f"pôvodný index {index}: {stav} {uloha['text']}")


print()
print("FILTROVANÝ ZOZNAM: iba nesplnené")
zobrazene_poradie = 1

for povodny_index, uloha in enumerate(ulohy):
    if not uloha["hotovo"]:
        stav = "[x]" if uloha["hotovo"] else "[ ]"
        print(f"zobrazené číslo {zobrazene_poradie}: {stav} {uloha['text']}  | pôvodný index: {povodny_index}")
        zobrazene_poradie += 1


print()
print("ZÁVER:")
print("Zobrazené číslo 2 neznamená automaticky pôvodný index 1.")
print("Pri filtri 'nesplnené' zobrazené číslo 2 patrí k pôvodnému indexu 2.")
