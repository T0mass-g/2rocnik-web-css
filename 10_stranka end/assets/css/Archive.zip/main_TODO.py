from ulohyIO import uloz_ulohy, nacitaj_ulohy
from ulohy_logika_TODO import (
    filtruj_ulohy_s_indexom,
    pridaj_ulohu,
    oznac_hotove_indexom,
    povodny_index_podla_poradia,
)


# ============================================================
# TERMINÁLOVÉ ROZHRANIE
# ------------------------------------------------------------
# Táto časť programu komunikuje s používateľom cez print()
# a input().
#
# Dnes upravujeme problém:
# používateľ vyberá podľa filtrovaného výpisu,
# ale program musí nájsť pôvodný index úlohy.
# ============================================================


def text_uloh_pre_vypis(zoznam, filter_r="vsetky"):
    """Pripraví textové riadky pre konzolový výpis zoznamu úloh."""
    vybrane = filtruj_ulohy_s_indexom(zoznam, filter_r)
    riadky = []

    for poradie, dvojica in enumerate(vybrane, start=1):
        povodny_index = dvojica[0]
        uloha = dvojica[1]

        stav = "[x]" if uloha["hotovo"] else "[ ]"

        # Poznámka:
        # Používateľovi zobrazujeme poradie od 1.
        # Pôvodný index zatiaľ nezobrazujeme, ale program si ho vie zistiť.
        riadky.append(f"{poradie}. {stav} {uloha['text']}")

    return riadky


def zmen_filter(volba):
    """Preloží voľbu z terminálového menu na názov filtra."""
    if volba == 1:
        return "vsetky"
    elif volba == 2:
        return "hotove"
    elif volba == 3:
        return "nesplnene"
    else:
        return "vsetky"


externy_subor = "ulohy.json"
ulohy = nacitaj_ulohy(externy_subor)

if len(ulohy) == 0:
    ulohy = [
        {"text": "Napísať domácu úlohu", "hotovo": False},
        {"text": "Prečítať kapitolu", "hotovo": True},
        {"text": "Pripraviť sa na test", "hotovo": False}
    ]

akt_filter = "vsetky"

while True:
    print("\nZOZNAM ÚLOH:")
    texty = text_uloh_pre_vypis(ulohy, akt_filter)

    for riadok in texty:
        print(riadok)

    print("\nAktuálny filter:", akt_filter)
    print("1 - pridať úlohu")
    print("2 - označiť ako hotové")
    print("3 - zmeniť filter")
    print("0 - koniec")

    volba = input("Vyber možnosť: ")

    if volba == "1":
        text = input("Zadaj novú úlohu: ")
        pridaj_ulohu(ulohy, text)
        uloz_ulohy(ulohy, externy_subor)

    elif volba == "2":
        cislo = int(input("Číslo úlohy vo filtrovanom zozname: "))

        # TODO:
        # 1. Pomocou povodny_index_podla_poradia() zisti pôvodný index.
        # 2. Ak je index -1, vypíš "Taká úloha neexistuje."
        # 3. Inak použi oznac_hotove_indexom().
        # 4. Ak sa označenie podarí, vypíš "Úloha bola označená ako hotová."
        # 5. Po zmene ulož úlohy.
        pass

    elif volba == "3":
        volba_filtra = int(input("1 - všetky\n2 - hotové\n3 - nesplnené\n"))
        akt_filter = zmen_filter(volba_filtra)

    elif volba == "0":
        break

    else:
        print("Neplatná voľba.")
